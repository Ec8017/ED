#' Title
#' Economic dispatch
#'
#' @param demand
#' load demand time series
#' @param cost
#' cost function
#' @param constrain
#' generator constrain
#' @param speed
#' wind speed time series
#' @param scenarios
#' the number of wind power simulations
#' @return
#' generator generation time series
#' @export
#'
#' @examples
#' Demand = c(227, 213, 208, 201, 202, 203, 210, 223, 251, 276, 283, 288, 277, 271, 285, 285, 288, 290, 298, 292, 288, 282, 272, 262)
#' Cost = c(213.1, 11.669, 0.00533, 200, 10.333, 0.00889, 240, 10.833, 0.00741)
#' Cost = matrix(Cost, nrow = 3, ncol = 3, byrow = TRUE)
#' Constrain = c(50.0, 200, 37.5, 150, 45.0, 180)
#' Constrain = matrix(Constrain, nrow = 3, ncol = 2, byrow = TRUE)
#' Speed = c(2.5, 4.2, 3.5, 3, 3.9, 3.7, 4, 5, 4.5, 4.4, 4.6, 5.3, 5, 4.7, 5.5, 5.9, 5, 4.4, 3, 3.5, 3.9, 2.9, 3.9, 4)
#' Scenario = 1
#' p = ED(Demand, Cost, Constrain, Speed, Scenario)

ED = function(demand, cost, constrain, speed, scenarios = 1){
  # objective function
  obj = function(x){
    x1 = x[1]
    x2 = x[2]
    x3 = x[3]
    cost1 = cost[1,1] + cost[1,2] * x1 + cost[1,3] * x1^2
    cost2 = cost[2,1] + cost[2,2] * x2 + cost[2,3] * x2^2
    cost3 = cost[3,1] + cost[3,2] * x3 + cost[3,3] * x3^2
    return(cost1 + cost2 + cost3)
  }
  # the number of time series
  ts = length(demand)
  # density of air
  d = 1.27
  # WP : windpower
  WP = 0.5*d*speed^3

  A = c(1,0,0,-1,0,0,0,1,0,0,-1,0,0,0,1,0,0,-1,1,1,1)
  A = matrix(A, 7, 3, byrow = TRUE)
  constrain[,2] = -constrain[,2]

  # WPG : wind power generation
  WPG = matrix(rep(0,ts*scenarios), nrow = scenarios)
  for(s in 1:scenarios){
    WPG[s,] = WP * rnorm(ts,0.33,0.05)
  }
  # the mean of WPG
  WPG_mean = rep(NA,ts)
  for(t in 1:ts){
    WPG_mean[t] = mean(WPG[,t])
  }
  # NetLoad
  NetLoad = demand - WPG_mean
  # solve optimization problem
  result = matrix(ts*3, nrow = 3, ncol = ts)
  for(t in 1:24){
    b = c(t(constrain)[1:6], NetLoad[t])
    r = constrOptim(theta = -constrain[,2]-1, f = obj, grad = NULL, ui = A, ci = b)
    result[,t] = r$par
  }
  return(result)
}
